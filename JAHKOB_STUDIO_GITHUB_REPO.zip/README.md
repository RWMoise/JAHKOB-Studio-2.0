# 🎙️ JAHKOB STUDIO – App Mobile Audio (PWA)

**JAHKOB STUDIO** se yon Progressive Web App (PWA) pou mizisyen ak kreyatè son.

## ✨ Fonksyonalite
- 🎤 Anrejistre vwa w ak efè (Echo, Reverb, AutoGain)
- 🎹 Jwe not sou klavye vityèl (Piano & Gita)
- 📤 Telechaje oswa voye fichye anrejistre
- 📱 Enstalab sou telefòn ak tablèt
- 📴 Itilize san koneksyon (offline mode)

## 🚀 Kijan pou itilize li
1. Klike sou lyen GitHub Pages la (ap vin parèt)
2. Peze **Kòmanse** pou anrejistre, **Sispann**, epi **Telechaje**
3. Jwe not sou klavye a
4. Chwazi efè ou vle (Reverb, Echo, AutoGain)

## 📦 Ki sa ki ladan
- `index.html` – App prensipal la
- `manifest.json` – Meta done pou enstalasyon mobil
- `service-worker.js` – Offline caching
- `sounds/` – Son pou not yo (piano/gita)
- `icon-192.png`, `icon-512.png` – Ikòn app la

## 🔧 Enstalasyon sou mobil
- Louvri app la ak Chrome / Safari
- Chwazi **“Ajouter à l'écran d'accueil”** pou w enstale li

## 👤 Otè
**JAHKOB PRODUCTION**  
2025 – Mizik. Enspirasyon. Teknoloji.
